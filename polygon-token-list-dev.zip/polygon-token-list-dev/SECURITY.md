# Polygon Technology Security Information

## Link to vulnerability disclosure details (Bug Bounty).
- Websites and Applications: https://hackerone.com/polygon-technology
- Smart Contracts: https://immunefi.com/bounty/polygon

## Languages that our team speaks and understands.
Preferred-Languages: en

## Security-related job openings at Polygon.
https://polygon.technology/careers

## Polygon security contact details.
security@polygon.technology

## The URL for accessing the security.txt file.
Canonical: https://polygon.technology/security.txt
